from django.shortcuts import render
from .forms import InputForm
from .forms import GeeksForm
from .models import GeeksModel
 
# Create your views here.
# def home_view(request):
#     context ={}
 
#     # create object of form
#     form = GeeksForm(request.POST or None, request.FILES or None)
     
#     # check if form data is valid
#     if form.is_valid():
#         # save the form data to model
#         form.save()
 
#     context['form']= form
#     return render(request, "home.html", context)


from django.shortcuts import render
  
# relative import of forms
from .forms import GeeksForm
  
# importing formset_factory
from django.forms import formset_factory


from django.shortcuts import render
from .forms import GeeksForm
 
def home_view(request):
    context ={}
 
    # create object of form
    form = GeeksForm(request.POST or None, request.FILES or None)
     
    # check if form data is valid
    if form.is_valid():
        # save the form data to model
        form.save()
 
    context['form']= form
    return render(request, "home.html", context)

  
# def formset_view(request):
#     context ={}
  
#     # creating a formset
#     GeeksFormSet = formset_factory(GeeksForm)
#     formset = GeeksFormSet()
      
#     # Add the formset to context dictionary
#     context['formset']= formset
#     return render(request, "home.html", context)




# def formset_view(request):
#     context ={}
  
#     # creating a formset and 5 instances of GeeksForm
#     GeeksFormSet = formset_factory(GeeksForm, extra = 5)
#     formset = GeeksFormSet()
      
#     # Add the formset to context dictionary
#     context['formset']= formset
#     return render(request, "home.html", context)



from django.shortcuts import render
  
# relative import of forms
from .forms import GeeksForm
  
# importing formset_factory
from django.forms import formset_factory
  
def formset_view(request):
    context ={}
  
    # creating a formset and 5 instances of GeeksForm
    GeeksFormSet = formset_factory(GeeksForm, extra = 5)
    formset = GeeksFormSet(request.POST or None)
      
    # print formset data if it is valid
    if formset.is_valid():
        for form in formset:
            print(form.cleaned_data)
              
    # Add the formset to context dictionary
    context['formset']= formset
    return render(request, "home.html", context)